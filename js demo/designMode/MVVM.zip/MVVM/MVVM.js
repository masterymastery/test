class MVVM {
    constructor(el,data){
        this.$el = el
        this.$data = data
        if(this.$el){
            
        }
    }
}
